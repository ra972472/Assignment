package Pages;
import org.openqa.selenium.WebDriver;

import Locators.*;
import Utils.SeleUtils;


public class LoginPg extends SeleUtils
{
	public static void login(WebDriver driver, String email) throws InterruptedException 
	{	
		LoginLoc.loginEle(driver).click();
		LoginLoc.contiEmail(driver).click();
		LoginLoc.enterEmailLoc(driver).sendKeys(email);
		LoginLoc.sendOTPLoc(driver).click();
		waitt(40);
	//	LoginLoc.getAppLoc(driver).click();
		//waitt(5);
	//	snap(driver, "GetApp");
	//	driver.navigate().back();
	}
}
