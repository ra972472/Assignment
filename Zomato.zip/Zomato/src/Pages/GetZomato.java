package Pages;

import org.openqa.selenium.WebDriver;
import Locators.GetZomatoLoc;
import Utils.SeleUtils;

public class GetZomato extends SeleUtils
{
	public static void getZomatoApp(WebDriver driver) throws Exception
	{		
		scr(driver, 1500);
		GetZomatoLoc.phone(driver).click();	waitt(2);
		GetZomatoLoc.email(driver).click(); waitt(2);
		GetZomatoLoc.emailSend(driver).sendKeys("sxyzsh371@gmail.com");		waitt(2);
		GetZomatoLoc.shareAppLink(driver).click();
		waitt(2);
	}
}
