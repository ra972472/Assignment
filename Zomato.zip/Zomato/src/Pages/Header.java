package Pages;

import org.openqa.selenium.WebDriver;

import Locators.HeaderLoc;
import Utils.SeleUtils;

public class Header extends SeleUtils
{
	public static void searchItem(WebDriver wd, String item) throws InterruptedException 
	{
		waitt(3);
	//	HeaderLoc.selectLocationLoc(wd).click();
		//HeaderLoc.dropLocationLoc(wd).click();
		HeaderLoc.searchRestLoc(wd).sendKeys(item);
		HeaderLoc.searchRestLoc(wd).click();
		waitt(3);
		HeaderLoc.searchButtonLoc(wd).click(); waitt(5);
		//wd.navigate().back();
	}

}
