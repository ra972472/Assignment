package Pages;

import org.openqa.selenium.WebDriver;

import Locators.ContLoc;
import Utils.SeleUtils;


public class Cont extends SeleUtils
{
	static WebDriver driver=null;
	
	public static void container(WebDriver driver) throws Exception
	{
		waitt(1.5);
		scr(driver, 300);								waitt(2);
		
		hover(driver, ContLoc.orderFoodOnline(driver));	waitt(2);
		ContLoc.orderFoodOnline(driver).click();		waitt(2);
		
		driver.navigate().back();						waitt(2);
		
		hover(driver, ContLoc.goOutForMeal(driver));	waitt(2);
		hover(driver, ContLoc.nightwayClub(driver));	waitt(2);
		hover(driver, ContLoc.zomatoPro(driver));
		
		waitt(2);
		scr(driver, 800);								waitt(1.5);
		
		ContLoc.trendingThisWeek(driver).click();       waitt(2);
		driver.navigate().back();
		ContLoc.bestOfDelhiNcr(driver).click();      	waitt(2);
		driver.navigate().back();
		ContLoc.workFriendlyPlaces(driver).click();		waitt(2);
		driver.navigate().back();
		ContLoc.forTheFamily(driver).click();			waitt(2);
		driver.navigate().back();
		ContLoc.allDelhiNcr(driver).click();			waitt(2);
		driver.navigate().back();
		
		
	}
	

}
