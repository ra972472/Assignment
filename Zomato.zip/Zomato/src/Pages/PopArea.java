package Pages;

import org.openqa.selenium.WebDriver;
import Locators.PopAreaLoc;
import Utils.SeleUtils;

public class PopArea extends SeleUtils
{
	public static void accPop(WebDriver driver) throws InterruptedException 
	{
		scr(driver, 1300);
		PopAreaLoc.connaughtPlace(driver).click();		waitt(0.8);
		snap(driver, "Connaught");						waitt(0.8);
		driver.navigate().back();
		waitt(0.8);

		hover(driver, PopAreaLoc.gurgaon(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.noida(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.rajouri(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.saket(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.cyberCity(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.golfcourse(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.dlfPhase4(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.delhiUniversity(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.indirapuram(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.vasantKunj(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.greaterKailash1(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.chanakyapuri(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.rohini(driver));			waitt(0.8);
		hover(driver, PopAreaLoc.janpath(driver));	  		waitt(0.8);
		
		scr(driver, 200);
		hover(driver, PopAreaLoc.hauzkhas(driver));			waitt(0.8);
		hover(driver, PopAreaLoc.sector38(driver));			waitt(0.8);
		hover(driver, PopAreaLoc.janakpuri(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.sector50(driver));			waitt(0.8);
		hover(driver, PopAreaLoc.mgRoad(driver));			waitt(0.8);
		hover(driver, PopAreaLoc.dlfPhase3(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.punjabiBagh(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.netajiSubhash(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.malviyaNagar(driver));		waitt(0.8);
		
		scr(driver, 300);
		hover(driver, PopAreaLoc.khanMarket(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.karolBagh(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.nehruPlace(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.sohnaRoad(driver));		waitt(0.8);
		hover(driver, PopAreaLoc.greaterKailash2(driver));	waitt(0.8);
		hover(driver, PopAreaLoc.pitampura(driver));
	}
}
