package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class PopAreaLoc {
	static WebElement location = null;
	static Actions hover = null;

	public static WebElement connaughtPlace(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text()='Connaught Place (380 places)']"));

		return location;
	}

	public static WebElement gurgaon(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Sector 29, Gurgaon (201 places)']"));

		return location;
	}

	public static WebElement noida(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Sector 18, Noida (259 places)']"));

		return location;
	}

	public static WebElement rajouri(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Rajouri Garden (487 places)']"));

		return location;
	}

	public static WebElement saket(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Saket (608 places)']"));

		return location;
	}

	public static WebElement cyberCity(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'DLF Cyber City (178 places)']"));

		return location;
	}

	public static WebElement golfcourse(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Golf Course Road (288 places)']"));

		return location;
	}

	public static WebElement dlfPhase4(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'DLF Phase 4 (564 places)']"));

		return location;
	}

	public static WebElement delhiUniversity(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Delhi University-GTB Nagar (266 places)']"));

		return location;
	}

	public static WebElement indirapuram(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Indirapuram (1179 places)']"));

		return location;
	}

	public static WebElement vasantKunj(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Vasant Kunj (715 places)']"));

		return location;
	}

	public static WebElement greaterKailash1(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Greater Kailash 1 (GK1) (324 places)']"));

		return location;
	}

	public static WebElement chanakyapuri(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Chanakyapuri (128 places)']"));

		return location;
	}

	public static WebElement rohini(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Rohini (1916 places)']"));

		return location;
	}

	public static WebElement janpath(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Janpath (53 places)']"));

		return location;
	}

	public static WebElement hauzkhas(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Hauz Khas Village (62 places)']"));

		return location;
	}

	public static WebElement sector38(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Sector 38, Noida (97 places)']"));

		return location;
	}

	public static WebElement janakpuri(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Janakpuri (635 places)']"));

		return location;
	}

	public static WebElement sector50(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Sector 50, Gurgaon (394 places)']"));

		return location;
	}

	public static WebElement mgRoad(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'MG Road, Gurgaon (288 places)']"));

		return location;
	}

	public static WebElement dlfPhase3(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'DLF Phase 3 (751 places)']"));

		return location;
	}

	public static WebElement punjabiBagh(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Punjabi Bagh (232 places)']"));

		return location;
	}

	public static WebElement netajiSubhash(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Netaji Subhash Place (118 places)']"));

		return location;
	}

	public static WebElement malviyaNagar(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Malviya Nagar (726 places)']"));

		return location;
	}

	public static WebElement khanMarket(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Khan Market (55 places)']"));

		return location;
	}

	public static WebElement karolBagh(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Karol Bagh (431 places)']"));

		return location;
	}

	public static WebElement nehruPlace(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Nehru Place (89 places)']"));

		return location;
	}

	public static WebElement sohnaRoad(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Sohna Road (595 places)']"));

		return location;
	}

	public static WebElement greaterKailash2(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Greater Kailash 2 (GK2) (165 places)']"));

		return location;
	}

	public static WebElement pitampura(WebDriver driver) {
		location = driver.findElement(By.xpath("//h5[text() = 'Pitampura (556 places)']"));

		return location;
	}

}
