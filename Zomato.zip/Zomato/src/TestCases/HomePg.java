package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Locators.OrderLoc;
import Utils.SeleUtils;

public class HomePg extends SeleUtils
{
	public static void doOrder(WebDriver driver) throws InterruptedException 
	{
		waitt(2);
		driver.findElement(By.xpath("//img[@alt='Restaurant Card']")).click();
		//driver.findElement(By.xpath("//IMG[@src=\"https://b.zmtcdn.com/data/pictures/chains/1/19136191/53fdcbef5d66af5798f704a61f4d7211_o2_featured_v2.jpg?output-format=webp\"]")).click();;
		waitt(3);
		
		scr(driver, 700);
		waitt(1);
		OrderLoc.add(driver).click();		waitt(2);
		try {
		OrderLoc.add(driver).click();		waitt(2); } catch(Exception e) {}
		
		OrderLoc.acc(driver).click();
		
		try {
		OrderLoc.addToOrd(driver).click();
		} catch(Exception e) {}
		
//		driver.findElement(By.xpath(""))
		
		OrderLoc.cont(driver).click();      waitt(1);
		

		OrderLoc.home(driver).click();    	waitt(.8);
		OrderLoc.conToP(driver).click();    waitt(1);

		
//		OrderLoc.edit(driver).click();      waitt(.8);
		OrderLoc.cAdd(driver).sendKeys("adfadf");    	waitt(.8);
		OrderLoc.work(driver).click();      waitt(1);	
		OrderLoc.saveNP(driver).click();    waitt(.8);
		
	//	OrderLoc.verifyPh(driver).click();    waitt(.8);
		//OrderLoc.zomato(driver).click();    waitt(.8);
	//	OrderLoc.conToP(driver).click();    waitt(.8);
		
		
	}

}
