package TestCases;

import java.util.concurrent.TimeUnit;
import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.Cont;
import Pages.GetZomato;
import Pages.Header;
import Pages.LoginPg;
import Pages.PopArea;

public class TestLogin 
{
	public static WebDriver driver;
	
	
	@BeforeTest
	public void initBrow()
	{
		System.out.println("Launching In Chrome...\n");
		System.setProperty("webdriver.chrome.driver", "D:\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		// MAXIMIZING THE SCREEN
		driver.manage().window().maximize();
		
		// LOGIN TO THE SYSTEM
		driver.navigate().to("http://www.zomato.com/ncr"); 
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	
	@Test
	public void main() throws Exception 
	{
		
//		LoginPg.login(driver, "yuvarajanbu6@gmail.com");
		
		Header.searchItem(driver, "Noodles");
		
		HomePg.doOrder(driver);
//		
//		Cont.container(driver);
//		
//		GetZomato.getZomatoApp(driver);
		
//		PopArea.accPop(driver);
		
		
		
		System.out.println("Success!!!");
	}
	
	
	@org.testng.annotations.AfterClass
	public void closeBrow() throws InterruptedException
	{
		Thread.sleep(3000);
		//driver.quit();
	}
}
